import SpriteClass from '../../rpjs/engine/sprite.js';
import CloudBlockClass from './cloud_block.js';
import BreakBlockStrongClass from '../code/break_block_strong.js';
import BallClass from './ball.js';
import AxeClass from './axe.js';

export default class ExecutionerClass extends SpriteClass {
        
    constructor(game,x,y,data) {
        super(game,x,y,data);
        
        // constants
        this.TILE_IDX_BUMP=18;
        this.MAX_SPEED=8;
        this.JUMP_HEIGHT=-40;
        
        this.COLLIDE_CLASS_IGNORE=[AxeClass];
        
        // variables  
        this.executionerSpeed=0;
        this.lastLaunchXPosition=-1;
        this.launchXPositionsLeft=null; // array of axe launch positions, loaded on startup
        this.launchXPositionsRight=null;
        this.isDropping=true;
        this.inAir=false;
        this.isDead=false;
        this.isFirstShow=true;
        
        this.launchLeft=true;
        this.launchPos=null;
        
            // setup
        
        this.addImage('sprites/executioner_1');
        this.addImage('sprites/executioner_2');
        this.setCurrentImage('sprites/executioner_1');
        
        this.show=false;            // start with it not shown, button starts it
        this.gravityFactor=0.15;
        this.gravityMinValue=3;
        this.gravityMaxValue=30;
        this.canCollide=true;
        this.canStandOn=true;
        
        Object.seal(this);
    }
    
    duplicate(x,y)
    {
        return(new ExecutionerClass(this.game,x,y,this.data));
    }
    
    mapStartup()
    {
        this.launchXPositionsLeft=this.data.get('axe_x_launch_left');
        this.launchXPositionsRight=this.data.get('axe_x_launch_right');
        this.lastLaunchXPosition=-1;
        this.isDropping=true;
        this.inAir=false;
        this.isDead=false;
        this.isFirstShow=true;
        
        this.launchLeft=true;
        this.launchPos=this.launchXPositionsLeft.slice();
        
        this.game.startCompletionTimer();
    }
    
    fireAxe()
    {
        let n,ex,launchX,sx,sy;
        
            // time to switch to other list?
            
        if (this.launchPos.length===0) {
            this.launchPos=this.launchLeft?this.launchXPositionsRight.slice():this.launchXPositionsLeft.slice();
            this.launchLeft=!this.launchLeft;
        }
        
            // are we at the next launch position
            
        ex=Math.trunc((this.x+Math.trunc(this.width*0.5))/this.game.map.MAP_TILE_SIZE);
        
        for (n=0;n!=this.launchPos.length;n++) {
            launchX=this.launchPos[n];
            
            if (ex===launchX) {
                
                    // only fire one at a time
                    
                this.launchPos.splice(n,1);
                
                    // fire
                    
                sx=(launchX*this.game.map.MAP_TILE_SIZE)+Math.trunc(this.game.map.MAP_TILE_SIZE*0.5);
                sy=this.y-Math.trunc(this.height*0.5);

                this.game.map.addSprite(new AxeClass(this.game,sx,sy,null));
                
                this.playSound('jump');
                return;
            }
        }
    }
    
    run()
    {
        let time, oldTime;
        let map=this.game.map;
        let speed,bumpUp;
        let playerSprite=this.getPlayerSprite();
        
            // the first time we get called is
            // when we first appear, so play sound fx
            
        if (this.show) {
            if (this.isFirstShow) {
                this.isFirstShow=false;
                this.playSound('boss_appear');
            }
        }
        
            // we have a special check for dropping
            // out of the sky, ignore everything until
            // we hit ground
            
        if (this.isDropping) {
            if (!this.grounded) return;
            
            this.isDropping=false;
            map.shake(10);
            this.playSound('thud');
        }
        else {
            if (!this.grounded) {
                this.inAir=true;
            }
            else {
                if (this.inAir) {
                    this.inAir=false;
                    map.shake(3);
                    this.playSound('thud');
                }
            }
        }
        
            // dead, do nothig
            
        if (this.isDead) {
            this.y+=4;
            return;
        }
        
            // image
            
        if ((Math.trunc(this.game.timestamp/200)&0x1)===0) {
            this.setCurrentImage('sprites/executioner_1');
        }
        else {
            this.setCurrentImage('sprites/executioner_2');
        }
        
            // always follow the player, but with
            // an acceleration
            
        if ((playerSprite.x+Math.trunc(playerSprite.width*0.5))<(this.x+Math.trunc(this.width*0.5))) {
            if (this.executionerSpeed>-this.MAX_SPEED) {
                this.executionerSpeed-=0.5;
            }
            else {
                this.executionerSpeed=-this.MAX_SPEED;
            }
        }
        else {
            if (this.executionerSpeed<this.MAX_SPEED) {
                this.executionerSpeed+=0.5;
            }
            else {
                this.executionerSpeed=this.MAX_SPEED;
            }
        }
        
            // we need to bump up at collisions to get the
            // executioner can get out of holes he's digging
        
        speed=Math.trunc(this.executionerSpeed);
        this.x+=speed;
        
        if (this.checkCollision(this.COLLIDE_CLASS_IGNORE)) {
            this.x-=speed;

                // run collisions

            bumpUp=false;

            if (this.collideSprite!==null) {
                if (this.collideSprite instanceof BreakBlockStrongClass) bumpUp=true;
                this.collideSprite.interactWithSprite(this,null);
             }

                // only check for bumping if we are in the air, otherwise
                // just complete the jump

            if (this.grounded) {
                bumpUp=bumpUp||(this.collideTileIdx===this.TILE_IDX_BUMP);
                if (bumpUp) this.addGravity(this.JUMP_HEIGHT,0);
            }
        }
        
            // time to fire axe?

        this.fireAxe();
        
        // hit the liquid?
        if (this.isInLiquid()) {
            this.isDead=true;
            this.gravityFactor=0.0;
            this.game.map.addParticle((this.x+Math.trunc(this.width*0.5)),(this.y-Math.trunc(this.height*0.5)),64,256,1.0,0.01,0.1,8,'particles/skull',30,0.0,false,2500);
            this.playSound('boss_dead');
            
            // update the state
            this.game.setData(('boss_'+map.name),true);
            this.game.setData(('boss_explode_'+map.name),true);
            this.game.setData(('time_'+map.name),1000000);
        
            // update the time
            time=this.game.stopCompletionTimer();
            oldTime=this.game.getData('time_'+map.name);
            if (time<oldTime) this.game.setData(('time_'+map.name),time);

            // save the data
            this.game.persistData();
            
            map.forceCameraSprite=this;
            
            // warp player out
            this.sendMessage(this.getPlayerSprite(),'warp_out',null);
        }
    }
    
}
